/**
 * Single product behaviors.
 *
 * 1) Gallery hover flip: hovering the gallery shows the second image.
 *    Reuses Blocksy's flexy carousel -- the active slide is driven by the
 *    --current-item CSS custom property on .flexy-container (see
 *    inc/components/gallery.php in the parent theme), so thumbnail
 *    clicking keeps working untouched.
 *
 * 2) One price, always: for variable products the static summary price is
 *    replaced in place when a variation is chosen (WooCommerce's
 *    found_variation event supplies the correct per-variation price HTML),
 *    and restored on reset. The .woocommerce-variation-price recap block
 *    is hidden in CSS, so the page never shows two prices.
 */
(function ($) {
	function initHoverFlip() {
		if (!window.matchMedia || !window.matchMedia('(hover: hover)').matches) {
			return;
		}

		document
			.querySelectorAll('.woocommerce-product-gallery .flexy-container')
			.forEach(function (container) {
				if (container.querySelectorAll('.flexy-item').length < 2) {
					return;
				}

				var original =
					container.style.getPropertyValue('--current-item') || '0';

				container.addEventListener('mouseenter', function () {
					container.style.setProperty('--current-item', '1');
				});

				container.addEventListener('mouseleave', function () {
					container.style.setProperty('--current-item', original);
				});
			});
	}

	function initPriceSync() {
		var $form = $('.single-product .summary .variations_form');
		var $price = $('.single-product .summary.entry-summary > .price');

		if (!$form.length || !$price.length) {
			return;
		}

		var originalHtml = $price.html();

		$form.on('found_variation', function (event, variation) {
			if (variation && variation.price_html) {
				$price.html($(variation.price_html).html() || variation.price_html);
			}
		});

		$form.on('reset_data', function () {
			$price.html(originalHtml);
		});
	}

	/**
	 * A24-style variant swatches: buttons rendered next to each (hidden)
	 * variation <select> relay clicks into it, so WooCommerce's variation
	 * logic stays canonical. Classes re-sync on change/reset so the
	 * black/grey state always mirrors the real selection.
	 */
	function initVariantSwatches() {
		$('.single-product .summary .desire-variant-options[data-attribute]').each(
			function () {
				var $wrap = $(this);
				var $select = $wrap.closest('td.value').find('select');

				if (!$select.length) {
					return;
				}

				function sync() {
					var value = $select.val();

					$wrap.find('.desire-swatch').each(function () {
						$(this).toggleClass(
							'is-selected',
							String($(this).data('value')) === String(value)
						);
					});
				}

				$wrap.on('click', '.desire-swatch', function () {
					$select.val($(this).data('value')).trigger('change');
					sync();
				});

				$select.on('change', sync);

				$select.closest('.variations_form').on('reset_data', function () {
					setTimeout(sync, 10);
				});

				sync();
			}
		);
	}

	/**
	 * Buy Now -> checkout. A native form.submit() bypasses Blocksy's ajax
	 * add-to-cart, so WooCommerce processes the add server-side and the
	 * woocommerce_add_to_cart_redirect filter sends the shopper to
	 * checkout. For variable products we require a resolved variation
	 * first; if none, fall back to the normal button so its validation
	 * message surfaces.
	 */
	function initBuyNow() {
		$('.single-product .summary').on('click', '.desire-buy-now', function (e) {
			e.preventDefault();

			var $form = $(this).closest('form.cart');

			if (!$form.length) {
				return;
			}

			if ($form.hasClass('variations_form')) {
				var vid = $form.find('input.variation_id').val();

				if (!vid || vid === '0') {
					$form.find('.single_add_to_cart_button').trigger('click');
					return;
				}
			}

			if (!$form.find('input[name="desire_buy_now"]').length) {
				$form.append('<input type="hidden" name="desire_buy_now" value="1">');
			}

			// Native submit -> bypasses the jQuery ajax handler.
			$form.get(0).submit();
		});
	}

	$(function () {
		initHoverFlip();
		initPriceSync();
		initVariantSwatches();
		initBuyNow();
	});
})(jQuery);
