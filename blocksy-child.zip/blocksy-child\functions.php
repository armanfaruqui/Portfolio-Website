<?php
/**
 * Désiré child theme functions.
 *
 * Nothing here duplicates parent theme logic. The parent theme's
 * functions.php (wp-content/themes/blocksy/functions.php) already contains
 * site-specific hooks -- variable-product sale price formatting, the
 * "Add to cart" button text override, and the shop-loop hover image --
 * and those keep running unmodified: WordPress loads a child theme's
 * functions.php first, then the parent's, so both fire.
 */

/**
 * Inherit the parent's Customizer settings (header builder, colors,
 * product layout, AND the Additional CSS reference custom_css_post_id
 * that holds the whole site design) into this child theme's own
 * theme_mods_{stylesheet} store.
 *
 * Why not `after_switch_theme` with an empty-check: on activation
 * WordPress pre-seeds the child's mods with housekeeping keys
 * (nav_menu_locations, sidebars_widgets, custom_css_post_id => -1, a
 * stray `0 => false`), so the child is never literally "empty" and a
 * naive guard skips the copy -- which is exactly what left the site
 * unstyled once. Instead we run on every load (cheap) but gate on a
 * one-time flag, and detect "not yet inherited" by the ABSENCE of a real
 * Blocksy design key (header_placements) rather than emptiness. Once the
 * child has real settings, this never touches them again.
 */
add_action('after_setup_theme', function () {
	if (get_option('desire_child_mods_inherited')) {
		return;
	}

	$child_mods = get_option('theme_mods_blocksy-child', []);

	// Already inherited or independently configured -> leave it, flag done.
	if (is_array($child_mods) && isset($child_mods['header_placements'])) {
		update_option('desire_child_mods_inherited', 1);
		return;
	}

	$parent_mods = get_option('theme_mods_blocksy');

	if (is_array($parent_mods) && ! empty($parent_mods)) {
		update_option('theme_mods_blocksy-child', $parent_mods);
	}

	update_option('desire_child_mods_inherited', 1);
});

add_action('wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'desire-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		['ct-main-styles'],
		wp_get_theme()->get('Version')
	);

	if (is_product()) {
		wp_enqueue_script(
			'desire-product',
			get_stylesheet_directory_uri() . '/js/product.js',
			['jquery'],
			wp_get_theme()->get('Version'),
			true
		);
	}
}, 20);

/**
 * Long "living creature" description, rendered in two spots with CSS
 * choosing which one shows:
 *   - Desktop: under the gallery images (fills the left column's empty
 *     space beneath the thumbnails).
 *   - Mobile: after Add to Cart in the summary, so the stacked order stays
 *     title -> materials -> price -> buy -> description (never description
 *     before the title, which is what putting it under the gallery would
 *     do once the columns stack).
 * Pulled from the queried product (not global $product, which can be a
 * variation inside the gallery render).
 */
if (! function_exists('desire_product_description_html')) {
	function desire_product_description_html($extra_class) {
		if (! is_product()) {
			return '';
		}

		$product = wc_get_product(get_queried_object_id());

		if (! $product instanceof WC_Product) {
			return '';
		}

		$desc = $product->get_description();

		if ($desc === '') {
			return '';
		}

		return '<div class="desire-product-description ' . esc_attr($extra_class) . '">'
			. wpautop(do_shortcode($desc))
			. '</div>';
	}
}

// Desktop placement: under the gallery.
add_action('blocksy:woocommerce:product-gallery:after', function () {
	echo desire_product_description_html('desire-desc-gallery');
});

// Mobile placement: after Add to Cart in the summary column.
add_action('blocksy:woocommerce:product-single:add_to_cart:after', function () {
	echo desire_product_description_html('desire-desc-summary');
});

/**
 * Remove the below-fold tabs entirely: the description now renders inside
 * the summary column, and the "Additional information" table (weight,
 * dimensions, attributes) adds nothing at this price point -- chain length
 * is already communicated by the variation dropdown.
 */
add_filter('woocommerce_product_tabs', function ($tabs) {
	if (is_product()) {
		return [];
	}

	return $tabs;
}, 98);

/**
 * Drop the product_meta layer (SKU / categories -- already CSS-hidden on
 * the live site, so it only contributed empty space) and the divider that
 * precedes it, so the column ends cleanly on the description.
 */
add_filter('blocksy:woocommerce:product-single:layout', function ($layout) {
	if (! is_array($layout)) {
		return $layout;
	}

	return array_values(array_filter($layout, function ($layer) {
		$id = isset($layer['id']) ? $layer['id'] : '';
		$uid = isset($layer['__id']) ? $layer['__id'] : '';

		return $id !== 'product_meta' && $uid !== 'divider_2';
	}));
});

/**
 * Breadcrumbs: render "Home" as text instead of the 15px house icon --
 * on product pages this trail is the only inline route back.
 */
add_filter('theme_mod_breadcrumb_home_item', function () {
	return 'text';
});

/**
 * Minimal top bar on product and cart pages. The Blocksy header is empty
 * on these pages (the homepage builds its own header out of blocks), so
 * without this there is no route home and -- worse -- no route to the
 * cart beyond the transient "View cart" link after adding an item.
 * Checkout is intentionally left bare (distraction-free).
 *
 * Cluster (right-aligned): Home / currency toggle / Cart. The currency
 * toggle reads CURCY's configured list (falls back to CAD/USD) and shows
 * every currency A24-style -- current black, others greyed links that
 * switch via CURCY's ?wmc-currency= param. All URLs resolve through
 * home_url()/wc_get_cart_url(), so nothing is tied to this environment.
 */
add_action('wp_body_open', function () {
	if (! function_exists('is_product') || ! (is_product() || is_cart())) {
		return;
	}

	$count = (function_exists('WC') && WC()->cart)
		? WC()->cart->get_cart_contents_count()
		: 0;

	$currencies = [];
	$wmc_params = get_option('woo_multi_currency_params');

	if (is_array($wmc_params) && ! empty($wmc_params['currency']) && is_array($wmc_params['currency'])) {
		$currencies = $wmc_params['currency'];
	}

	if (count($currencies) < 2) {
		$currencies = ['CAD', 'USD'];
	}

	$current_currency = function_exists('get_woocommerce_currency')
		? get_woocommerce_currency()
		: $currencies[0];

	?>
	<div class="desire-topbar">
		<a class="desire-topbar-link" href="<?php echo esc_url(home_url('/')); ?>">Home</a>

		<span class="desire-topbar-currency">
			<?php foreach ($currencies as $i => $code) { ?>
				<?php if ($i > 0) { ?><span class="desire-currency-sep">/</span><?php } ?>
				<?php if ($code === $current_currency) { ?>
					<span class="desire-currency is-current"><?php echo esc_html($code); ?></span>
				<?php } else { ?>
					<a class="desire-currency" href="<?php echo esc_url(add_query_arg('wmc-currency', $code)); ?>"><?php echo esc_html($code); ?></a>
				<?php } ?>
			<?php } ?>
		</span>

		<a class="desire-topbar-link desire-topbar-cart" href="<?php echo esc_url(wc_get_cart_url()); ?>">Cart<span class="desire-cart-count"><?php echo $count > 0 ? ' (' . (int) $count . ')' : ''; ?></span></a>
	</div>
	<?php
});

/**
 * "Return to shop" (empty cart) and "continue shopping" should land on
 * the homepage -- the storefront IS the homepage; there is no /shop page
 * worth sending anyone to. home_url() keeps it environment-agnostic.
 */
add_filter('woocommerce_return_to_shop_redirect', function () {
	return home_url('/');
});

add_filter('woocommerce_continue_shopping_redirect', function () {
	return home_url('/');
});

/**
 * Buy Now: skip the cart entirely and land the customer on checkout,
 * where the Stripe/Apple Pay express buttons live (already enabled on the
 * live site). Renders as the primary CTA alongside a secondary Add to Cart.
 *
 * The button is type="button" (not a submit) -- product.js does a NATIVE
 * form.submit(), which bypasses Blocksy's ajax add-to-cart handler so the
 * request is processed server-side and the redirect filter below can send
 * it to checkout. Guarded to the queried product so the parent theme's
 * loop-card forms don't sprout a Buy Now.
 */
add_action('woocommerce_after_add_to_cart_button', function () {
	global $product;

	if (! $product || $product->get_id() !== get_queried_object_id()) {
		return;
	}

	echo '<button type="button" class="desire-buy-now">Buy Now</button>';
});

add_filter('woocommerce_add_to_cart_redirect', function ($url) {
	if (isset($_REQUEST['desire_buy_now'])) {
		return wc_get_checkout_url();
	}

	return $url;
});

/**
 * A24-style variation picker: augment each variation <select> with a row
 * of text swatches (current black, others greyed). The select stays in
 * the DOM (hidden by CSS) as the source of truth -- product.js relays
 * swatch clicks into it, so WooCommerce's variation machinery (price,
 * stock, add-to-cart payload) is untouched. Covers Chain Length on the
 * Veevee pendants and Size on the Ondulé rings automatically.
 */
add_filter('woocommerce_dropdown_variation_attribute_options_html', function ($html, $args) {
	if (! is_product() || empty($args['options'])) {
		return $html;
	}

	// Skip the hidden add-to-cart forms the parent theme renders inside
	// related-product cards -- swatches belong to the main product only.
	if (
		! empty($args['product'])
		&&
		$args['product']->get_id() !== get_queried_object_id()
	) {
		return $html;
	}

	$selected = isset($args['selected']) ? $args['selected'] : '';

	$swatches = '<span class="desire-variant-options" data-attribute="attribute_' . esc_attr(sanitize_title($args['attribute'])) . '">';

	foreach ($args['options'] as $option) {
		// Display-only trim: "18 Inch Ball Chain" -> "18 Inch". The full
		// value is preserved in data-value for the form.
		$label = str_replace(' Ball Chain', '', $option);

		$swatches .= sprintf(
			'<button type="button" class="desire-swatch%s" data-value="%s">%s</button>',
			$option === $selected ? ' is-selected' : '',
			esc_attr($option),
			esc_html($label)
		);
	}

	$swatches .= '</span>';

	return $html . $swatches;
}, 10, 2);

/**
 * Veevee colorway row (Wasabi / Mochi / Yuzu): each colorway is its own
 * product, so this renders sibling links styled like the variant swatches,
 * with the current page highlighted. Siblings are discovered by title
 * prefix at runtime -- no hardcoded IDs or URLs -- so a future colorway
 * shows up automatically.
 */
add_action('woocommerce_before_add_to_cart_form', function () {
	global $product;

	if (! $product || strpos($product->get_name(), 'Veevee') !== 0) {
		return;
	}

	// The parent theme renders full add-to-cart forms inside related/shop
	// loop cards, which re-fires this hook once per card. Only render for
	// the product this page is actually about.
	if ($product->get_id() !== get_queried_object_id()) {
		return;
	}

	/**
	 * Display order + brand colors, keyed by colorway name.
	 * 'color' shows on the selected swatch; 'soft' (a ~50% white mix of
	 * the same hue) is the hover state on greyed-out siblings.
	 * NOTE: Yuzu hex assumed #f0c727 (yellow) -- adjust here if off.
	 */
	$colorways = [
		'Wasabi' => ['color' => '#85bc0f', 'soft' => '#c2dd87'],
		'Mochi' => ['color' => '#f087c7', 'soft' => '#f7c3e3'],
		'Yuzu' => ['color' => '#f0c727', 'soft' => '#f7e393'],
	];

	$siblings = wc_get_products([
		'status' => 'publish',
		'limit' => -1,
	]);

	$items = [];

	foreach ($siblings as $sibling) {
		$title = $sibling->get_name();

		if (strpos($title, 'Veevee') !== 0) {
			continue;
		}

		$parts = explode(' ', $title);

		$items[] = [
			'label' => isset($parts[1]) ? $parts[1] : $title,
			'id' => $sibling->get_id(),
			'url' => get_permalink($sibling->get_id()),
		];
	}

	if (count($items) < 2) {
		return;
	}

	// Order per the $colorways map; unknown colorways trail alphabetically.
	$order = array_flip(array_keys($colorways));

	usort($items, function ($a, $b) use ($order) {
		$a_rank = isset($order[$a['label']]) ? $order[$a['label']] : PHP_INT_MAX;
		$b_rank = isset($order[$b['label']]) ? $order[$b['label']] : PHP_INT_MAX;

		if ($a_rank === $b_rank) {
			return strcmp($a['label'], $b['label']);
		}

		return $a_rank - $b_rank;
	});

	echo '<div class="desire-variant-group desire-colorways">';
	echo '<span class="desire-variant-label">Colorway</span>';
	echo '<span class="desire-variant-options">';

	foreach ($items as $item) {
		$style = '';

		if (isset($colorways[$item['label']])) {
			$style = sprintf(
				' style="--swatch-color:%s;--swatch-color-soft:%s"',
				esc_attr($colorways[$item['label']]['color']),
				esc_attr($colorways[$item['label']]['soft'])
			);
		}

		if ($item['id'] === $product->get_id()) {
			echo '<span class="desire-swatch is-selected"' . $style . '>' . esc_html($item['label']) . '</span>';
		} else {
			echo '<a class="desire-swatch" href="' . esc_url($item['url']) . '"' . $style . '>' . esc_html($item['label']) . '</a>';
		}
	}

	echo '</span>';
	echo '</div>';
});

// Keep the top bar cart count fresh after ajax add-to-cart.
add_filter('woocommerce_add_to_cart_fragments', function ($fragments) {
	$count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;

	$fragments['.desire-cart-count'] = '<span class="desire-cart-count">'
		. ($count > 0 ? ' (' . (int) $count . ')' : '')
		. '</span>';

	return $fragments;
});

/**
 * Streamline the classic checkout for conversion.
 *
 * WooCommerce's address fields (city/state/postcode/...) are re-classed
 * CLIENT-SIDE from a per-country locale table the moment the country
 * field initializes -- so field classes must be set at the locale layer
 * (woocommerce_default_address_fields + woocommerce_get_country_locale),
 * not just on checkout_fields, or the JS rewrites them to full-width.
 */

// Address-field layer: drop Company everywhere, pair the address grid.
add_filter('woocommerce_default_address_fields', function ($fields) {
	unset($fields['company']);

	$classes = [
		'first_name' => ['form-row-first'],
		'last_name' => ['form-row-last'],
		'address_1' => ['form-row-wide', 'address-field'],
		'address_2' => ['form-row-wide', 'address-field'],
		'city' => ['form-row-first', 'address-field'],
		'state' => ['form-row-last', 'address-field'],
		'postcode' => ['form-row-first', 'address-field'],
	];

	foreach ($classes as $key => $class) {
		if (isset($fields[$key])) {
			$fields[$key]['class'] = $class;
		}
	}

	return $fields;
}, 20);

// Strip per-country class overrides so no locale swaps fields back to
// full-width when the shopper changes country.
add_filter('woocommerce_get_country_locale', function ($locale) {
	foreach ($locale as $country => $fields) {
		foreach ($fields as $key => $config) {
			unset($locale[$country][$key]['class']);
		}
	}

	return $locale;
}, 20);

// Contact-first ordering: email at the top (the one field worth capturing
// even on abandonment), phone paired at the end.
add_filter('woocommerce_checkout_fields', function ($fields) {
	if (isset($fields['billing']['billing_email'])) {
		$fields['billing']['billing_email']['priority'] = 1;
		$fields['billing']['billing_email']['class'] = ['form-row-wide'];
	}

	if (isset($fields['billing']['billing_phone'])) {
		$fields['billing']['billing_phone']['priority'] = 100;
		$fields['billing']['billing_phone']['class'] = ['form-row-last'];
	}

	return $fields;
}, 30);

// The giant "Order notes" textarea earns nothing at this order size.
add_filter('woocommerce_enable_order_notes_field', '__return_false');

// Collapse the duplicate shipping form by default -- most orders ship to
// the address just typed. The toggle stays for those who need it.
add_filter('woocommerce_ship_to_different_address_checked', '__return_false');

// "Billing details" reads like an invoice; this form is contact + where
// to send the piece.
add_filter('gettext_woocommerce', function ($translation, $text) {
	if ($text === 'Billing details') {
		return 'Contact & delivery';
	}

	return $translation;
}, 10, 2);

// "Related products" reads like a database column; retitle it.
add_filter('gettext_woocommerce', function ($translation, $text) {
	if ($text === 'Related products') {
		return 'You may also like';
	}

	return $translation;
}, 10, 2);
